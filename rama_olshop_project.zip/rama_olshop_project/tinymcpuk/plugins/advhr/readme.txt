Check the TinyMCE documentation for details on this plugin.

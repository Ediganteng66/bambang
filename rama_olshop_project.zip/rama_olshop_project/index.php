<?php
  header('location:home'); 
?>
